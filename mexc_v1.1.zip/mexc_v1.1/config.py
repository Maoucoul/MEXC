token = "WEB6e29d6520"
Cookie = ""
fingerprint = {
     "mtoken": "7428669779516026ff14be8fedce91ce", "mhash": "b54026998ba9b74ef86d848e64b40438", "sys": "Linux",
     "sys_ver": "", "browser_name": "Firefox", "browser_ver": "115.0", "kernel_name": "Gecko", "kernel_ver": "20100101",
     "gpu_type": "Radeon HD 3200 Graphics,AMD", "language": "en-US,en-US,en", "display_resolution": "1920,1080",
     "color_depth": "24", "total_memory": "", "pixel_ratio": 1, "time_zone": "Europe/Zaporozhye",
     "session_enable": "true", "storage_enable": "true", "indexeddb_enable": "true", "websql_enable": "false",
     "do_not_track": "false", "is_alphago": "false",
     "canvas_crc": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHoAAABuCAYAAADoHgdpAAAbN0lEQVR4Xu1dCZhVxZU+1RvNFkRkVARtQVREdhTXDLjghhvKIksji+BEkzjqJDFmJmYcM46jMWNcWBRX3DPiKDPEGFlEjdKNgmhQFCW4ERREoLfX/e78/30Lb7lL1X33vdcfcL6vbOyuW1W3/nuqTp2tlBSRrKOtI6VF+klUqjCMKrHsnweidELZD+Xv4sP7G35+i7IdZbMo+RTlEzzHn2vUx+oja+7bA0WifcWKHoM6/cRSXfG39vh3u3jhv78Xb+87/NyFUmf/tPBTKfbxroj1vpSVvKemD159tGUd2YK2ohwbihX76Ts+JfIpyid4jj/XfKzUR0WcZrtrjKNwZB1ldZSInI9eR2JyR6DnQwP1bjWJNAPzlh0owKpTo0h"
}

userAgent = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br",
    "Content-Type": "application/json",
    "Language": "English",
    "x-mxc-sign": None,
    "x-mxc-nonce": None,
    "Authorization": None,
    "Cookie": Cookie,
    "Pragma": "akamai-x-cache-on",
    "Origin": "https://futures.mexc.com",
    "Connection": "keep-alive",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "TE": "trailers"
}
#spot
coins = {
    "BTC_USDT": {
        "currencyId": "febc9973be4d4d53bb374476239eb219",
        "marketCurrencyId": "128f589271cb4951b03e71e6323eb7be"
    },
    "LTC_USDT": {
        "currencyId": "e9b47a809bd1456fa1d378f0d7db14ec",
        "marketCurrencyId": "128f589271cb4951b03e71e6323eb7be"
    }, # and etc broo
    # "coin": {
    #     "currencyId": "currencyId",
    #     "marketCurrencyId": "marketCurrencyId"
    # },
}
